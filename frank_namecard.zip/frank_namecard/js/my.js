app = angular.module('myApp', []);

//app.config(['cfpLoadingBarProvider', function(cfpLoadingBarProvider) {
//  cfpLoadingBarProvider.includeSpinner = true;
//  cfpLoadingBarProvider.spinnerTemplate = '<div>Loading...</div>';
//}]);

app.controller('contactCtrl', function ($scope, $http) {
	$scope.myFun=function(myfilter){
		$scope.contacts = $scope.origin;
		if(myfilter=="") {
			return;
		}
		var temp = new Array();
		for(var i=0; i<$scope.contacts.length; i++) {
			if($scope.contacts[i].name.indexOf(myfilter) != -1) {
				temp.push($scope.contacts[i]);
			}
		}
		$scope.contacts = temp;
	};
	
	$scope.generateCard=function(id) {
		for(var i=0; i<$scope.contacts.length; i++) {
			if($scope.contacts[i].id == id) {
				$scope.current = $scope.contacts[i];
				break;
			}
		}
	}
	
	$http.get('http://jsonplaceholder.typicode.com/users')
		.then(function (result) {
			
//			$scope.start = function() {
//		        cfpLoadingBar.start();
//		    };
//		
//		    $scope.complete = function () {
//		        cfpLoadingBar.complete();
//		    }
//		    cfpLoadingBar.start();
			
			if(true) {
				function sortByKey(array, key) {
					return array.sort(function(a, b) {
				        var x = a[key]; var y = b[key];
				        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
				    });
				}
				
				$scope.origin = sortByKey(result.data, 'name')
				$scope.contacts = $scope.origin;
				
	            
	            $scope.startLetter = [{"character": $scope.origin[0].name.substr(0,1), "count":1}];
	            for (var i = 1; i < $scope.origin.length; i++) {
	                var character = $scope.origin[i].name.substr(0,1);
	                for(var j=0; j<$scope.startLetter.length; j++) {
	                	if($scope.startLetter[j].character == character) {
	                		$scope.startLetter[j].count++;
	                		break;
	                	}
	                }
	                
	                if(j>=$scope.startLetter.length) {
	                	$scope.startLetter.push({"character":character, "count":1});
	                }
	                
	            }

	            
				console.log($scope.startLetter);
				return;
			}
			
		    
		}).catch(function(result) { //捕捉错误处理  
		    alert(result.data);  
		});  
});

